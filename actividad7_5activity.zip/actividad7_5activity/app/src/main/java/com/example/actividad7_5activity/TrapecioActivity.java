package com.example.actividad7_5activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;

public class TrapecioActivity extends AppCompatActivity {

    private EditText etBaseMayor;
    private EditText etBaseMenor;
    private EditText etAltura;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trapecio);

        // Enlaza las vistas con los elementos de diseño
        etBaseMayor = findViewById(R.id.etBaseMayor);
        etBaseMenor = findViewById(R.id.etBaseMenor);
        etAltura = findViewById(R.id.etAltura);
        tvResultado = findViewById(R.id.tvResultado);
        Button btnCalcular = findViewById(R.id.btnCalcular);
        Button btnRegresar = findViewById(R.id.btnRegresar);

        // Configura un listener para el botón "Calcular"
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularAreaYPerimetro();
            }
        });

        // Configura un listener para el botón "Regresar"
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Cierra esta actividad y regresa a la actividad anterior
            }
        });
    }

    // Método para calcular el área y el perímetro del trapecio
    private void calcularAreaYPerimetro() {
        String baseMayorStr = etBaseMayor.getText().toString().trim();
        String baseMenorStr = etBaseMenor.getText().toString().trim();
        String alturaStr = etAltura.getText().toString().trim();

        if (!baseMayorStr.isEmpty() && !baseMenorStr.isEmpty() && !alturaStr.isEmpty()) {
            double baseMayor = Double.parseDouble(baseMayorStr);
            double baseMenor = Double.parseDouble(baseMenorStr);
            double altura = Double.parseDouble(alturaStr);
            double area = (baseMayor + baseMenor) * altura / 2;
            double perimetro = baseMayor + baseMenor + 2 * Math.sqrt(Math.pow((baseMayor - baseMenor) / 2, 2) + Math.pow(altura, 2));

            // Redondea el resultado a dos decimales
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            String resultado = "Área del trapecio: " + decimalFormat.format(area) + "\n"
                    + "Perímetro del trapecio: " + decimalFormat.format(perimetro);

            // Muestra el resultado en el TextView
            tvResultado.setText(resultado);
        } else {
            // Si faltan valores, muestra un mensaje de error
            tvResultado.setText("Por favor, introduce los valores de las bases y la altura del trapecio.");
        }
    }
}
