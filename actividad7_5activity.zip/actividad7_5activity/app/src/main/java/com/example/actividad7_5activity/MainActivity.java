package com.example.actividad7_5activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obtén referencias a los botones en el diseño

        Button btnPiramide= findViewById(R.id.btnPIRAMIDE);
        Button btnCuadrado = findViewById(R.id.btnCUADRADO);
        Button btnTriangulo = findViewById(R.id.btnTRIANGULO);
        Button btnTrapecio = findViewById(R.id.btnTRAPECIO);
        Button btnOctagono = findViewById(R.id.btnOCTAGONO);



        // Asigna un listener al botón Triángulo
        btnPiramide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { iniciarNuevaActividad(PiramideActivity.class);
            }
        });

        btnCuadrado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarNuevaActividad(CuadradoActivity.class);
            }
        });
        btnTriangulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarNuevaActividad(TrianguloActivity.class);
            }
        });

        btnTrapecio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarNuevaActividad(TrapecioActivity.class);
            }
        });

        btnOctagono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { iniciarNuevaActividad(OctagonoActivity.class);
            }
        });
    }

    private void iniciarNuevaActividad(Class<?> cls) {
        Intent intent = new Intent(MainActivity.this, cls);
        startActivity(intent);
    }
}
